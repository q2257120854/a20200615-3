<?php
namespace app\api\controller;
use think\Controller;
use think\Session;
class Common extends Controller
{
	// 公共
	 
}

<?php
return [
  'iosurl' => 'https://www.pgyer.com/X71e',
  'andurl' => 'https://shouji.baidu.com/software/24772853.html',
];